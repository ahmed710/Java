package tn.tuniprob.tests;


import tn.tuniprob.gestionmagasin.Produit;
import tn.tuniprob.gestionmagasin.Magasin;
import java.util.Date;
import tn.tuniprod.gestionemployes.Caissier;
import tn.tuniprod.gestionemployes.Responsable;
import tn.tuniprod.gestionemployes.Vendeur;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author abdel
 */
public class MainProg {
    
    public static void main(String[] args) {
        
        Produit p0 = new Produit();
        Produit p1 = new Produit(1021, "Lait", "Délice");
        Produit p2 = new Produit(2510, "Yaourt", "Vitalait");
        Produit p3 = new Produit(3250, "Tomate", "Sicam", 1.200f);
        
        p0.afficher();
        p1.afficher();
        p2.afficher();
        p3.afficher();
        
        p1.setPrix(0.700f);
        p1.afficher();
        
        p0.setId(1000);
        p0.setLibelle("Oeuf");
        p0.setMarque("Mazraa");
        p0.setPrix(0.500f);
        
        p2.setPrix(0.500f);
        
        p0.afficher();
        p2.afficher();
        
        System.out.println(p0.toString());
        System.out.println(p1.toString());
        System.out.println(p2.toString());
        System.out.println(p3.toString());
        
        p0.setDateExpiration(new Date());
        p1.setDateExpiration(new Date());
        p2.setDateExpiration(new Date());
        p3.setDateExpiration(new Date());
        
        System.out.println("************** Prosit2 **************");
        Magasin m1 = new Magasin(1, "Carrefour", "Centre-Ville");
        m1.ajoutProduit(p0);
        m1.ajoutProduit(p2);
        m1.ajoutProduit(p3);
        m1.ajoutProduit(p1);
        System.out.println(m1.toString());
        System.out.println(m1.getCapacite());
        
        System.out.println("************** Prosit4 **************");
        Magasin m2 = new Magasin(2, "Monoprix", "Menzah 6");
        m2.ajoutProduit(p0);
        m2.ajoutProduit(p3);
        
        // Employés M1
        Caissier c1 = new Caissier(1, 1, "Caissier 1", "@1", 200);
        Caissier c2 = new Caissier(2, 2, "Caissier 2", "@2", 350);
        Vendeur v1 = new Vendeur(0.6f, 3, "Vendeur 1", "@3", 180);
        Responsable r1 = new Responsable(700, 4, "Responsable 1", "@4", 170);
        m1.ajoutEmploye(c1);
        m1.ajoutEmploye(c2);
        m1.ajoutEmploye(v1);
        m1.ajoutEmploye(r1);
        
        // Employés M2
        Caissier c3 = new Caissier(1, 5, "Caissier 3", "@5", 250);
        Vendeur v2 = new Vendeur(0.4f, 6, "Vendeur 2", "@6", 165);
        Vendeur v3 = new Vendeur(0.7f, 7, "Vendeur 3", "@7", 190);
        Vendeur v4 = new Vendeur(0.55f, 8, "Vendeur 4", "@8", 210);
        Responsable r2 = new Responsable(1200, 9, "Responsable 2", "@9", 230);
        m2.ajoutEmploye(c3);
        m2.ajoutEmploye(v2);
        m2.ajoutEmploye(v3);
        m2.ajoutEmploye(v4);
        m2.ajoutEmploye(r2);
        
        System.out.println(c1.toString());
        System.out.println(v1.toString());
        System.out.println(r1.toString());
        
        System.out.println("-----");
        System.out.println(m1.toString());
        System.out.println("-----");
        System.out.println(m2.toString());
    }
}
