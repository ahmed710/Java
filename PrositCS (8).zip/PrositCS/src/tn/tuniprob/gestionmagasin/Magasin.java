package tn.tuniprob.gestionmagasin;

import tn.tuniprod.gestionemployes.Employe;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author abdel
 */
public class Magasin {

    private int id;
    private String nom;
    private String adresse;
    private int capacite;
    private int capaciteEmploye;
    private Produit[] produits;
    private Employe[] employes;
    private final int MAX_PRODUITS = 50;
    private final int MAX_EMPLOYES = 20;

    public Magasin(int id, String nom, String adresse) {
        this.id = id;
        this.nom = nom;
        this.adresse = adresse;
        this.produits = new Produit[MAX_PRODUITS];
        this.employes = new Employe[MAX_EMPLOYES];
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public int getCapacite() {
        return capacite;
    }

    public void setCapacite(int capacite) {
        this.capacite = capacite;
    }

    public void ajoutProduit(Produit p) {
        if (!chercherProduit(p)) {
            if (p.getPrix() > 0) {
                if (capacite < MAX_PRODUITS) {
                    produits[capacite] = p;
                    capacite++;
                }
            } else {
                System.out.println("Le prix ne doit pas etre négatif !");
            }
        } else {
            System.out.println("Produit existe déjà !");
        }
    }
    
    public void ajoutEmploye(Employe e) {
        if(capaciteEmploye < MAX_EMPLOYES) {
            employes[capaciteEmploye] = e;
            capaciteEmploye++;
        }
    }
    
    public void supprimerProduit(Produit p) {
        if(chercherProduit(p)) {
            int index = -1;
            for(int i = 0; i < capacite; i++) {
                if(produits[i].comparer(p)) {
                    index = i;
                    break;
                }
            }
            for(int i = index; i < capacite - 1; i++) {
                produits[i] = produits[i+1];
            }
            capacite--;
            produits[capacite] = null;
            // produits[capacite--] = null;
        } else {
            System.out.println("Le produit n'existe pas !");
        }
    }

    public boolean chercherProduit(Produit p) {
        /*for(int i = 0; i < capacite; i++) {
            if(produits[i].comparer(p))
                return true;
        }
        return false;*/
        for (int i = 0; i < capacite; i++) {
            if (Produit.comparer(produits[i], p)) {
                return true;
            }
        }
        return false;
    }
    
    public static Magasin maxMagasin(Magasin m1, Magasin m2) {
        /*if(m1.capacite > m2.capacite)
            return m1;
        else
            return m2;*/
        return m1.capacite > m2.capacite ? m1 : m2;
    }

    public String toString() {
        String res = "id=" + this.id + ", nom=" + this.nom + ", adresse=" + this.adresse + ", capacité=" + this.capacite + ", produits:";
        for (int i = 0; i < capacite; i++) {
            res += "\n" + produits[i].toString();
        }
        res += "\nEmployés :";
        for (int i = 0; i < capaciteEmploye; i++) {
            res += "\n" + employes[i].toString();
        }
        return res;
    }
}
