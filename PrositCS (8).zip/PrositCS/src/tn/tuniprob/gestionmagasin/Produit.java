package tn.tuniprob.gestionmagasin;


import java.util.Date;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author abdel
 */
public class Produit {
    
    private int id;
    private String libelle;
    private String marque;
    private float prix;
    private Date dateExpiration;
    
    public Produit() {
    }
    
    public Produit(int id, String libelle, String marque) {
        this.id = id;
        this.libelle = libelle;
        this.marque = marque;
    }

    public Produit(int id, String libelle, String marque, float prix) {
        this.id = id;
        this.libelle = libelle;
        this.marque = marque;
        this.prix = prix;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public String getMarque() {
        return marque;
    }

    public void setMarque(String marque) {
        this.marque = marque;
    }

    public Date getDateExpiration() {
        return dateExpiration;
    }

    public void setDateExpiration(Date dateExpiration) {
        this.dateExpiration = dateExpiration;
    }
    
    public float getPrix() {
        return this.prix;
    }
    
    public void setPrix(float prix) {
        this.prix = prix;
    }
    
    public void afficher() {
        System.out.println("id="+this.id);
        System.out.println("libellé="+this.libelle);
        System.out.println("marque="+this.marque);
        System.out.println("prix="+this.prix);
    }
    
    public boolean comparer(Produit p) {
        return this.id == p.getId() && this.libelle == p.getLibelle()
                && this.prix == p.getPrix();
    }
    
    public static boolean comparer(Produit p1, Produit p2) {
        return p1.getId() == p2.getId()
                && p1.getLibelle() == p2.getLibelle()
                && p1.getPrix() == p2.getPrix();
    }
    
    public String toString() {
        return "id="+this.id+",libellé="+this.libelle
                +",marque="+this.marque+", prix="+this.prix;
    }
}
