/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tn.tuniprod.gestionemployes;

/**
 *
 * @author abdel
 */
public class Responsable extends Employe {
    
    private float prime;

    public Responsable(float prime, int id, String nom, String adresse, int nbrHeures) {
        super(id, nom, adresse, nbrHeures);
        this.prime = prime;
    }

    public float getPrime() {
        return prime;
    }

    public void setPrime(float prime) {
        this.prime = prime;
    }
    
    public String toString() {
        return super.toString() + ", prime=" + this.prime;
    }
    
    public float calculerSalaire() {
        int heuresSupp = (this.getNbrHeures() - 160) > 0 ? this.getNbrHeures() - 160 : 0;
        int heuresNonSupp = this.getNbrHeures() - heuresSupp;
        
        return (heuresNonSupp * 10) + (heuresSupp * 10 * 1.2f) + this.prime;
    }
}
