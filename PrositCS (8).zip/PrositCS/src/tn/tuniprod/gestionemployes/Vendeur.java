/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tn.tuniprod.gestionemployes;

/**
 *
 * @author abdel
 */
public class Vendeur extends Employe {
    
    private float tauxDeVente;

    public Vendeur(float tauxDeVente, int id, String nom, String adresse, int nbrHeures) {
        super(id, nom, adresse, nbrHeures);
        this.tauxDeVente = tauxDeVente;
    }

    public float getTauxDeVente() {
        return tauxDeVente;
    }

    public void setTauxDeVente(float tauxDeVente) {
        this.tauxDeVente = tauxDeVente;
    }
    
    public float calculerSalaire() {
        return 450 * (1 + this.tauxDeVente);
    }
    
    public String toString() {
        return super.toString() + ", tauxDeVente=" + this.tauxDeVente;
    }
}
