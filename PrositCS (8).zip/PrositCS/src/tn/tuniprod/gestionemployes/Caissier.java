/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tn.tuniprod.gestionemployes;

/**
 *
 * @author abdel
 */
public class Caissier extends Employe {
    
    private int numeroDeCaisse;
    
    public Caissier(int numeroDeCaisse, int id, String nom, String adresse, int nbrHeures) {
        super(id, nom, adresse, nbrHeures);
        this.numeroDeCaisse = numeroDeCaisse;
    }

    public int getNumeroDeCaisse() {
        return numeroDeCaisse;
    }

    public void setNumeroDeCaisse(int numeroDeCaisse) {
        this.numeroDeCaisse = numeroDeCaisse;
    }
    
    public float calculerSalaire() {
        int heuresSupp = (this.getNbrHeures() - 180) > 0 ? this.getNbrHeures() - 180 : 0;
        int heuresNonSupp = this.getNbrHeures() - heuresSupp;
        
        return (heuresNonSupp * 5) + (heuresSupp * 5 * 1.15f);
    }
    
    public String toString() {
        return super.toString() + ", numeroDeCaisse=" + this.numeroDeCaisse;
    }
}
